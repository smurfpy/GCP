# passport-auth-nodejs
<<<<<<< HEAD
=======

Create .env


copy code 

CLIENT_ID=574176005493-elo2blo35un6i9ho1nainehu9frcate9.apps.googleusercontent.com
CLIENT_SECRET=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
CALLBACK_URL=http://localhost:3000/auth/google/callback
MONGO_URI=mmongodb://localhost:27017/Permission