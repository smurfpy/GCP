const Teacher = require('./teacher.model')
const TeacherService = require('./teacher.service')

module.exports = TeacherService(Teacher)