const Classroom = require('./class.model')
const ClassroomService = require('./class.service')

module.exports = ClassroomService(Classroom)